package ru.geekbrains.qa.java2.lesson1.homeWork;

public enum Status {
    PassedDistance,NoPassedDistance
}
